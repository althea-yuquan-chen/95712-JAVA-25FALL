package DataPackage;

// Simple container for a String
class ContainedClass {
    String str = "";

    public void setStr(String str) {
        this.str = str;
    }
}
